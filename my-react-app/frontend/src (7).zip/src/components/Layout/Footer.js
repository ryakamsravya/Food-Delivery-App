import React from 'react'

const Footer = () => {
  return (
    <>
    {/* <div className="py-1"> */}
         {/* <p className="text-center mt-1> */}
        <footer>
            <p className="text-center mt-1">Food Delivery Website-2023-2024,All Rights Reserved...
        </p>
        </footer>
        {/* </div> */}
      
    </>
  )
}

export default Footer
